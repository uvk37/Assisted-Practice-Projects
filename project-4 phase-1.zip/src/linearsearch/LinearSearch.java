package linearsearch;

import java.util.Scanner;

	public class LinearSearch {
		public static int Linearsearch (int array[],int x) {
			int n=array.length;
			
			for(int i=0;i<n;i++) {
				if(array[i]==x)
					return i;
				
			}
			return -1;
		}

	    public static void main(String[] args){
	    	int array[]= {1,2,3,4,9,8,7,6};
	    	Scanner sc=new Scanner(System.in);
	    	System.out.println("enter the element to be searched:");
	    	int searchValue = sc.nextInt();
	        int result =Linearsearch(array,searchValue);
	    	
	    	if(result== -1) 
	    		System.out.println("Element not found");
	    	else 
	    			System.out.println(" Element found at index:" + result);
	    		}
}
