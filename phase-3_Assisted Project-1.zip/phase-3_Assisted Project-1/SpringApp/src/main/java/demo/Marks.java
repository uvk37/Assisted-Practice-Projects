package demo;

public class Marks {
	
	private float phy;
	private float chem;
	private float maths;
	public float getPhy() {
		return phy;
	}
	public void setPhy(float phy) {
		this.phy = phy;
	}
	public float getChem() {
		return chem;
	}
	public void setChem(float chem) {
		this.chem = chem;
	}
	public float getMaths() {
		return maths;
	}
	public void setMaths(float maths) {
		this.maths = maths;
	}
	
	

}