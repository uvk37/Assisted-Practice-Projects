package accessmodifiers2;

import accessmodifiers1.*;
public class Accessspecifiers3 extends Proaccessspecifiers {
	public static void main(String[] args) {
		Accessspecifiers3 obj = new Accessspecifiers3 ();   
	       obj.display();  
	}


}