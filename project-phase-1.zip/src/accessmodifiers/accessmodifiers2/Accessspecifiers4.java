package accessmodifiers2;

import accessmodifiers1.*;

public class Accessspecifiers4{
public static void main(String[] args) {
		
		Pubaccessspecifiers obj = new Pubaccessspecifiers(); 
        obj.display();  
		
	}


}