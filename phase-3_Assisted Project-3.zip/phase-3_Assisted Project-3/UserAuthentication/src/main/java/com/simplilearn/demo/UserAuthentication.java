package com.simplilearn.demo;

public class UserAuthentication {
	public String username()
	{
		String email = "abc@gmail.com";
		return email;
	}
	
	public String paswd()
	{
		String password = "1234";
		return password;
	}
	
	

}
