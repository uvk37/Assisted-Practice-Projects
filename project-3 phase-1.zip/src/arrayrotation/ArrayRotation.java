package arrayrotation;

class RotateArray {
	
	public void rotate(int[] nums, int n) {
		if (n > nums.length)
			n = n % nums.length;
		int[] result = new int[nums.length];
		for (int i = 0; i < n; i++) {
			result[i] = nums[nums.length - n + i];
		}
		int j = 0;
		for (int i = n; i < nums.length; i++) {
			result[i] = nums[j];
			j++;
		}
		System.arraycopy(result, 0, nums, 0, nums.length);
	}
}

public class ArrayRotation {
	public static void main(String[] args) {
		RotateArray r = new RotateArray();
		int arr[] = {9, 8, 7, 6, 5, 4, 3, 2, 1 };
		r.rotate(arr, 6);
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
	}

}
